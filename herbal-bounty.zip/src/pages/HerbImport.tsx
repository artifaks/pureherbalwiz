
import HerbImport from "@/components/HerbImport";

export function HerbImportPage() {
  return <HerbImport />;
}

export default HerbImportPage;
